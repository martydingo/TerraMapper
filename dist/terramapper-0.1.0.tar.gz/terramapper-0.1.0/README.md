# TerraMapper

## Overview

A python module to generate an image of a Terraria world from a worldfile, with deepzoom support. This has been rewritten using functions sourced from [flyingsnake](https://github.com/Steffo99/flyingsnake), as I required the image generation to be created within a python stack, and not generated via a shell command. 

## Usage

```

```